// Import Phaser
import Phaser from 'phaser';

// Define chess game configuration
const config = {
  type: Phaser.AUTO,
  width: 640,
  height: 640,
  backgroundColor: '#f3f3f3',
  scene: {
    preload: preload,
    create: create,
    update: update
  }
};

// Initialize Phaser game
const game = new Phaser.Game(config);

// Preload function to load game assets
function preload() {
  this.load.image('board', 'assets/board.png');
  this.load.spritesheet('pieces', 'assets/pieces.png', {
    frameWidth: 64,
    frameHeight: 64
  });
}

// Create function to create game objects
function create() {
  // Add board sprite
  this.add.sprite(0, 0, 'board').setOrigin(0, 0);

  // Create chess pieces
  for (let i = 0; i < 8; i++) {
    for (let j = 0; j < 8; j++) {
      let piece = null;
      if (j < 2 || j > 5) {
        piece = this.add.sprite(i * 64 + 32, j * 64 + 32, 'pieces', 0);
        piece.setInteractive();
        this.input.setDraggable(piece);
        piece.setData('pieceType', 'pawn');
      }
    }
  }

  // Set input events
  this.input.on('dragstart', function (pointer, gameObject) {
    this.children.bringToTop(gameObject);
  }, this);

  this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
    gameObject.x = dragX;
    gameObject.y = dragY;
  });

  this.input.on('dragend', function (pointer, gameObject) {
    // Check for valid move and update piece position
    const tileX = Math.floor(gameObject.x / 64);
    const tileY = Math.floor(gameObject.y / 64);
    const pieceType = gameObject.getData('pieceType');
    const isValidMove = validateMove(pieceType, gameObject.x, gameObject.y);

    if (isValidMove) {
      gameObject.x = tileX * 64 + 32;
      gameObject.y = tileY * 64 + 32;
    } else {
      gameObject.x = gameObject.input.dragStartX;
      gameObject.y = gameObject.input.dragStartY;
    }
  });
}

// Update function for game logic
function update() {
  // Update game logic here
}

// Function to validate piece move
function validateMove(pieceType, x, y) {
  // Implement piece movement logic here
  // Return true if move is valid, false otherwise
  return true;
}
